package math.objects

public class Vector3(a: Double, b: Double, c: Double) {

    public val x = a;
    public val y = b;
    public val z = c;

}