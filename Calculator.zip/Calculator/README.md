# Calculator

Zdrojový repozitář mého školního projektu vzorcové kalkulačky pro Android

## Funkce

### M
- Vektorový součin
- Skalární součin

### F
